﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {

        Excel.Application xlApp;
        Excel.Workbook xlWorkBook = null;
        Excel.Worksheet xlWorkSheet = null;
        object misValue = System.Reflection.Missing.Value;
        string SystemName, InventoryToolVersion, AuditToolVersion, Customer,Cust_System, InventoryRunStarted, InventoryRunCompleted;


        DataSet ds = new DataSet();
        XmlReader xmlFile;
        XmlDataModel xmlDataModel = new XmlDataModel();
        

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult drResult = openFileDialog1.ShowDialog();
            if (drResult == System.Windows.Forms.DialogResult.OK)
                txtXmlFilePath.Text = openFileDialog1.FileName;
        }

        public Form1()
        {
            InitializeComponent();
            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            // xmlFile = XmlReader.Create(@"C:\ProgramData\Honeywell\Service Tools\SI\Level3Data\SATPCReport_ESV3B_01162019_170543.xml", new XmlReaderSettings());
            //ds.ReadXml(xmlFile);
            

        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (chkCustomeName.Checked && txtCustomeFileName.Text != "" && txtXmlFilePath.Text != "") // using Custome Xml File Name
            {
                if (File.Exists(txtXmlFilePath.Text)) // Checking XMl File is Exist or Not
                {
                    string CustXmlFilePath = Path.Combine(new FileInfo(txtXmlFilePath.Text).DirectoryName, txtCustomeFileName.Text); // Ceating Path for Xml Files
                    nodeextract(txtXmlFilePath.Text);
                    Createsheets(CustXmlFilePath);

                    MessageBox.Show("Conversion Completed!!");
                }

            }
            else if (!chkCustomeName.Checked || txtXmlFilePath.Text != "") // Using Default Xml File Name
            {
                if (File.Exists(txtXmlFilePath.Text)) // Checking XMl File is Exist or Not
                {
                    FileInfo fi = new FileInfo(txtXmlFilePath.Text);
                    string XlFile = fi.DirectoryName + "\\" + fi.Name.Replace(fi.Extension, ".xlsx");

                    nodeextract(txtXmlFilePath.Text);
                    Createsheets(XlFile);

                    MessageBox.Show("Conversion Completed!!");
                }
            }
            else
            {
                MessageBox.Show("Please Fill Required Feilds!!");
            }

            
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }


        private void generateall(string nameofthesheet, int index, int sheetindex)
        {

            int i = 0;
            int j = 0;




            //foreachtable
            //for (int tabel = 0; tabel < ds.Tables.Count; tabel++)
            //{

            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(sheetindex);
            xlWorkSheet.Name = nameofthesheet;
            xlWorkSheet.Rows.AutoFit();
            xlWorkSheet.Application.ActiveWindow.SplitRow = 1;
            xlWorkSheet.Application.ActiveWindow.FreezePanes = true;


            for (j = 0; j <= ds.Tables[index].Columns.Count - 1; j++)
            {
                xlWorkSheet.Cells[i + 1, 1] = ds.Tables[index].Columns[j].ToString();
                xlWorkSheet.Cells[i + 1, 1].Font.Bold = true;
                xlWorkSheet.Cells[i + 1, 1].Font.Color = ColorTranslator.ToOle(Color.White);
                Excel.Range formatRange = xlWorkSheet.UsedRange;
                Excel.Range cell = formatRange.Cells[i + 1, 1];


                cell.Interior.Color = ColorTranslator.ToOle(Color.Orange);

                for (int k = 0; k < ds.Tables[index].Rows.Count; k++)
                {
                    xlWorkSheet.Cells[i + 1, k + 2] = ds.Tables[index].Rows[k].ItemArray[j];

                }


                i++;


            }



           


            xlWorkBook.SaveAs(@"C:\ProgramData\Honeywell\Service Tools\SI\Level3Data\xml2excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlApp);
            releaseObject(xlWorkBook);
            releaseObject(xlWorkSheet);

            MessageBox.Show("Done .. ");
        }

        private void nodeextract(string Inputfilepath)
        {

            XmlDocument xmldoc = new XmlDocument();
            XmlNodeList xmlnode;
            int i;
            //FileStream fs = new FileStream(@"C:\ProgramData\Honeywell\Service Tools\SI\Level3Data\SATPCReport_ESV3B_01162019_170543.xml", FileMode.Open, FileAccess.Read);
            FileStream fs = new FileStream(Inputfilepath, FileMode.Open, FileAccess.Read);
            xmldoc.Load(fs);
            xmlnode = xmldoc.GetElementsByTagName("Node");

            //node details
            SystemName = xmldoc.GetElementsByTagName("SystemName")[0].InnerText.ToString();
            AuditToolVersion = xmldoc.GetElementsByTagName("AuditToolVersion")[0].InnerText.ToString();
            Customer = xmldoc.GetElementsByTagName("Customer")[0].InnerText.ToString();
            Cust_System = xmldoc.GetElementsByTagName("System")[0].InnerText.ToString();
            InventoryRunStarted = xmldoc.GetElementsByTagName("AuditStarted")[0].InnerText.ToString();
            InventoryRunCompleted = xmldoc.GetElementsByTagName("AuditCompleted")[0].InnerText.ToString();



            List<string> lst_vendorid = new List<string>();
            List<string> lst_appid = new List<string>();
            List<string> lst_temp = new List<string>();
            for (i = 0; i <= xmlnode.Count - 1; i++)
            {
                lst_appid.Clear();
                lst_vendorid.Clear();
                lst_temp.Clear();

                //Node Name
                string NodeNameref = xmlnode[i].FirstChild.InnerText;

                //######General Information     

                //processors Node
                XmlNodeList processorsNodes = xmlnode[i].ChildNodes[17].ChildNodes;
                List<Processors> list_processors = new List<Processors>();

                for (int i_processor = 0; i_processor < processorsNodes.Count - 1; i_processor++)
                {
                    if (processorsNodes[i_processor].HasChildNodes)
                    {

                        Processors pd = new Processors
                        {
                            ProcessorId = processorsNodes[i_processor].ChildNodes[0].InnerText,
                            ProcessorSpeed = processorsNodes[i_processor].ChildNodes[1].InnerText,
                            ProcessorCoreQuantity = processorsNodes[i_processor].ChildNodes[2].InnerText,
                        };
                        list_processors.Add(pd);



                    }

                }


                //Networks Node
                XmlNodeList NetworksNodes = xmlnode[i].ChildNodes[18].ChildNodes;
                List<Networks> list_networks = new List<Networks>();

                for (int i_network = 0; i_network < NetworksNodes.Count - 1; i_network++)
                {
                    if (NetworksNodes[i_network].HasChildNodes)
                    {

                        Networks nw = new Networks
                        {
                            // ProcessorId = processorsNodes[i_processor].ChildNodes[0].InnerText, 
                            NetworkCard = NetworksNodes[i_network].ChildNodes[0].InnerText,
                            NetworkName = NetworksNodes[i_network].ChildNodes[1].InnerText,
                            IpAddress = NetworksNodes[i_network].ChildNodes[2].InnerText,
                            SubnetMask = NetworksNodes[i_network].ChildNodes[3].InnerText,
                            DefaultGateway = NetworksNodes[i_network].ChildNodes[4].InnerText,
                            DNS_Primary = NetworksNodes[i_network].ChildNodes[5].InnerText,
                            MAC_Address = NetworksNodes[i_network].ChildNodes[6].InnerText,
                            InterfaceMetric = NetworksNodes[i_network].ChildNodes[7].InnerText,
                            NICDriverVersion = NetworksNodes[i_network].ChildNodes[8].InnerText

                        };
                        list_networks.Add(nw);



                    }

                }


                //Drives Node
                XmlNodeList DriveNodes = xmlnode[i].ChildNodes[19].ChildNodes;
                List<Drives> list_drive = new List<Drives>();
                for (int i_drive = 0; i_drive < DriveNodes.Count; i_drive++)
                {
                    if (DriveNodes[i_drive].HasChildNodes)
                    {

                        Drives dv = new Drives
                        {
                            // ProcessorId = processorsNodes[i_processor].ChildNodes[0].InnerText, 
                            DeviceID = DriveNodes[i_drive].ChildNodes[0].InnerText,
                            DiskFree = DriveNodes[i_drive].ChildNodes[1].InnerText,
                            DiskSize = DriveNodes[i_drive].ChildNodes[2].InnerText,
                            DiskUsed = DriveNodes[i_drive].ChildNodes[3].InnerText,
                            FileSystem = DriveNodes[i_drive].ChildNodes[4].InnerText,


                        };
                        list_drive.Add(dv);



                    }

                }


                //hardDiskConfiguration Node
                XmlNodeList harddiskConfigurationNodes = xmlnode[i].ChildNodes[20].ChildNodes;

                HardDiskConfiguration Hdc = new HardDiskConfiguration();
                if (harddiskConfigurationNodes.Count > 0)
                {

                    Hdc.Description = harddiskConfigurationNodes[0].InnerText;
                    Hdc.DriverVersion = harddiskConfigurationNodes[1].InnerText;
                    Hdc.PNPID = harddiskConfigurationNodes[2].InnerText;
                    Hdc.Type = harddiskConfigurationNodes[3].InnerText;

                }


                xmlDataModel.generalInformationeachNodes.Add(new GeneralInformationeachNode {

                    NodeName = xmlnode[i].ChildNodes[0].InnerText,
                    LoggedOnUser = xmlnode[i].ChildNodes[1].InnerText,
                    PartOfDomain = xmlnode[i].ChildNodes[2].InnerText,
                    DomainWorkGroupName = xmlnode[i].ChildNodes[3].InnerText,
                    CurrentTimeZone = xmlnode[i].ChildNodes[4].InnerText,
                    DaylightSavingEnabled = xmlnode[i].ChildNodes[5].InnerText,
                    Manufacturer = xmlnode[i].ChildNodes[6].InnerText,
                    Model = xmlnode[i].ChildNodes[7].InnerText,
                    BIOSVersion = xmlnode[i].ChildNodes[8].InnerText,
                    SerialNumber = xmlnode[i].ChildNodes[9].InnerText,
                    PhysicalMemory = xmlnode[i].ChildNodes[10].InnerText,
                    VirtualMemory = xmlnode[i].ChildNodes[11].InnerText,
                    PageFileMaximumSize = xmlnode[i].ChildNodes[12].InnerText,
                    PageFileLocation = xmlnode[i].ChildNodes[13].InnerText,
                    OperatingSystem = xmlnode[i].ChildNodes[14].InnerText,
                    ServicePack = xmlnode[i].ChildNodes[15].InnerText,
                    ProductId = xmlnode[i].ChildNodes[16].InnerText,
                    processors = list_processors,
                    netwroks = list_networks,
                    drivces = list_drive,
                    hardDiskConfiguration = Hdc

                });


                //#################






                //Installed Application Info
                XmlNodeList xn = xmlnode[i].ChildNodes[21].ChildNodes;


                for (int k = 0; k < xn.Count; k++)
                {
                    lst_vendorid.Add(xn[k].FirstChild.InnerText);
                    lst_appid.Add(xn[k].LastChild.InnerText);
                }

                xmlDataModel.InstalledApps.Add(new InstalledAppsEachNode { NodeName = NodeNameref, ApplicationID = lst_appid, VendorID = lst_vendorid });



                //Honeywell Applications data
                XmlNodeList xmlNode_HoneywellApplications = xmlnode[i].ChildNodes[22].ChildNodes;
                List<string> lsthwapps = new List<string>();

                for (int k = 0; k < xmlNode_HoneywellApplications.Count; k++)
                {
                  
                    if (xmlNode_HoneywellApplications[k].HasChildNodes)
                    {

                        foreach (XmlNode xn1 in xmlNode_HoneywellApplications[k].ChildNodes)
                        {

                            if (xn1.HasChildNodes)
                            {
                                for (int xn2 = 0; xn2 < xn1.ChildNodes.Count; xn2++)
                                {
                                    lsthwapps.Add(xn1.ChildNodes[xn2].InnerText);
                                }
                            }
                            else { lsthwapps.Add(xn1.InnerText); }


                           

                        }

                    }

                        //lsthwapps.Add(xmlNode_HoneywellApplications[k].InnerText);

                }

                xmlDataModel.HoneywellInstalledApplications.Add(new HoneywellApplicationsEachNode { NodeName = NodeNameref, Applicationvalues = lsthwapps });



                //Honeywell Licenses
                XmlNodeList xmlNode_HoneywellLicences = xmlnode[i].ChildNodes[23].ChildNodes;
                List<string> lic = new List<string>();
                for (int k = 0; k < xmlNode_HoneywellLicences.Count; k++)
                {
                    
                    if (xmlNode_HoneywellLicences[k].HasChildNodes)
                    {

                        foreach (XmlNode xninside in xmlNode_HoneywellLicences[k].ChildNodes)
                        {

                            lic.Add(xninside.InnerText);

                        }

                    }
                    else
                        lic.Add(xmlNode_HoneywellLicences[k].InnerText);

                }
                xmlDataModel.HoneywellLicenses.Add(new HoneywellLicensesEachNode { NodeName = NodeNameref, Licensesvalues = lic });


                //Honeywell Update Sections

                XmlNodeList xmlNode_Honeywellupdates = xmlnode[i].ChildNodes[24].ChildNodes;

                for (int k = 0; k < xmlNode_Honeywellupdates.Count; k++)
                {
                    if (xmlNode_Honeywellupdates[k].HasChildNodes)
                    {


                        List<HoneywellUpdate> list_honeywellupdate = new List<HoneywellUpdate>();
                        foreach (XmlNode xninside in xmlNode_Honeywellupdates[k].ChildNodes)
                        {

                            HoneywellUpdate hu = new HoneywellUpdate();
                            List<string> hulist = new List<string>();
                            hu.InstalledDate = xninside.ChildNodes[0].InnerText;
                            if (xninside.ChildNodes.Count > 2)
                            {

                                for (int index_updatenode = 1; index_updatenode <= xninside.ChildNodes.Count - 1; index_updatenode++)
                                {
                                    hulist.Add(xninside.ChildNodes[index_updatenode].InnerText);
                                }

                            }
                            hu.UpdateName = hulist;
                            list_honeywellupdate.Add(hu);

                        }
                        xmlDataModel.HoneywellUpdates.Add(new HoneywellUpdatesEachNode { NodeName = NodeNameref, UpdateEntity = list_honeywellupdate });

                    }
                    else
                        lst_temp.Add(xmlNode_HoneywellLicences[k].InnerText);


                }

                // Uninstyall Registry Entries 
                XmlNodeList xmlNode_UninstallRegistryEntries = xmlnode[i].ChildNodes[25].ChildNodes;

                List<UninstalledRegistryEntry> list_uninstalledRegistry = new List<UninstalledRegistryEntry>();


                for (int k = 0; k < xmlNode_UninstallRegistryEntries.Count; k++)
                {

                    UninstalledRegistryEntry ure = new UninstalledRegistryEntry
                    {
                        Number = xmlNode_UninstallRegistryEntries[k].ChildNodes[0].InnerText,
                        KeyName = xmlNode_UninstallRegistryEntries[k].ChildNodes[1].InnerText,
                        ProductName = xmlNode_UninstallRegistryEntries[k].ChildNodes[2].InnerText,
                        ProductVersion = xmlNode_UninstallRegistryEntries[k].ChildNodes[3].InnerText,
                        InstallDate = xmlNode_UninstallRegistryEntries[k].ChildNodes[4].InnerText,
                        ParentProductName = xmlNode_UninstallRegistryEntries[k].ChildNodes[5].InnerText,
                        ParentKeyName = xmlNode_UninstallRegistryEntries[k].ChildNodes[6].InnerText,
                        Publisher = xmlNode_UninstallRegistryEntries[k].ChildNodes[7].InnerText
                    };

                    list_uninstalledRegistry.Add(ure);
                }

                xmlDataModel.uninstalledRegistryEntries.Add(new UninstalledRegistryEntryEachNode { NodeName = NodeNameref, UninstalledRegistryEntryEntity = list_uninstalledRegistry });

            }
              
        }

        private void Createsheets( string outputfilepath)
        {
            xlWorkBook = xlApp.Workbooks.Add(misValue);

            List<string> SheetNames = new List<string>();

            SheetNames.Add("General Information");

            SheetNames.Add("Installed Apps");

            SheetNames.Add("Honeywell App Info");

            SheetNames.Add("Honeywell License");

            SheetNames.Add("Honeywell Updates");

            SheetNames.Add("Uninstall Registry Entries");

            for(int k=1;k<SheetNames.Count;k++)
                xlWorkBook.Worksheets.Add();

          

            for (int i = 0; i < SheetNames.Count; i++)
            {

                xlWorkSheet = xlWorkBook.Worksheets[i+1];
                //xlWorkSheet.Columns.AutoFit();
                //xlWorkSheet.Rows.AutoFit();
                xlWorkSheet.Columns.ColumnWidth = 30;

                xlWorkSheet.Activate();
                //Active Window
                xlWorkSheet.Application.ActiveWindow.SplitRow = 1;

                //FreePane 
                xlWorkSheet.Application.ActiveWindow.FreezePanes = true;

               
                

                int rowIndex = 0;

                if (i == 0)
                {
                    xlWorkSheet.Rows.WrapText = true;
                    xlWorkSheet.Cells.EntireColumn[1].Interior.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                    xlWorkSheet.Cells[1,1] = "Computer Name";
                    xlWorkSheet.Cells[1,1].Font.Bold = true;
                    xlWorkSheet.Cells[1,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[2,1] = "";
                    xlWorkSheet.Cells[2,1].Font.Bold = true;
                    xlWorkSheet.Cells[2,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[3,1] = "LoggedOn User";
                    xlWorkSheet.Cells[3,1].Font.Bold = true;
                    xlWorkSheet.Cells[3,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[4,1] = "PartOfDomain";
                    xlWorkSheet.Cells[4,1].Font.Bold = true;
                    xlWorkSheet.Cells[4,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[5,1] = "Domain WorkGroupName";
                    xlWorkSheet.Cells[5,1].Font.Bold = true;
                    xlWorkSheet.Cells[5,1].Font.Color = System.Drawing.
                    ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[6,1] = "Current TimeZone";
                    xlWorkSheet.Cells[6,1].Font.Bold = true;
                    xlWorkSheet.Cells[6,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[7,1] = "DaylightSavingEnabled";
                    xlWorkSheet.Cells[7,1].Font.Bold = true;
                    xlWorkSheet.Cells[7,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[8,1] = "Manufacturer";
                    xlWorkSheet.Cells[8,1].Font.Bold = true;
                    xlWorkSheet.Cells[8,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[9,1] = "Model";
                    xlWorkSheet.Cells[9,1].Font.Bold = true;
                    xlWorkSheet.Cells[9,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[11,1] = "BIOS Version";
                    xlWorkSheet.Cells[11,1].Font.Bold = true;
                    xlWorkSheet.Cells[11,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[12,1] = "Serial Number";
                    xlWorkSheet.Cells[12,1].Font.Bold = true;
                    xlWorkSheet.Cells[12,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[13,1] = "Physical Memory";
                    xlWorkSheet.Cells[13,1].Font.Bold = true;
                    xlWorkSheet.Cells[13,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[14,1] = "Virtual Memory";
                    xlWorkSheet.Cells[14,1].Font.Bold = true;
                    xlWorkSheet.Cells[14,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[15,1] = "Page File Maximum Size";
                    xlWorkSheet.Cells[15,1].Font.Bold = true;
                    xlWorkSheet.Cells[15,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[16,1] = "PageFile Location";
                    xlWorkSheet.Cells[16,1].Font.Bold = true;
                    xlWorkSheet.Cells[16,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[17,1] = "Operating System";
                    xlWorkSheet.Cells[17,1].Font.Bold = true;
                    xlWorkSheet.Cells[17,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[18,1] = "Service Pack";
                    xlWorkSheet.Cells[18,1].Font.Bold = true;
                    xlWorkSheet.Cells[18,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    xlWorkSheet.Cells[19,1] = "Product ID";
                    xlWorkSheet.Cells[19,1].Font.Bold = true;
                    xlWorkSheet.Cells[19,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                    List<int> ProcessorBiggestIndexArray = new List<int>();
                    for (int genindex = 0; genindex < xmlDataModel.generalInformationeachNodes.Count;genindex++)
                    {
                        ProcessorBiggestIndexArray.Add(xmlDataModel.generalInformationeachNodes[genindex].processors.Count);
                    }
                    int ProcessorBiggestcount = ProcessorBiggestIndexArray.Max();

                    for (int k = 0; k < xmlDataModel.generalInformationeachNodes.Count; k++)
                    {
                        Excel.Borders border = xlWorkSheet.Columns[k + 2].Borders;
                        border.LineStyle = Excel.XlLineStyle.xlContinuous;
                        border.Weight = 2d;


                        //General information
                        xlWorkSheet.Cells[1, k + 2].EntireRow.Font.Bold = true;
                        xlWorkSheet.Cells[1, k + 2] = xmlDataModel.generalInformationeachNodes[k].NodeName.ToString();



                     
                        xlWorkSheet.Cells[5, k + 2] = xmlDataModel.generalInformationeachNodes[k].DomainWorkGroupName.ToString();

                       
                        xlWorkSheet.Cells[6, k + 2] = xmlDataModel.generalInformationeachNodes[k].CurrentTimeZone.ToString();

                  
                        xlWorkSheet.Cells[7, k + 2] = xmlDataModel.generalInformationeachNodes[k].DaylightSavingEnabled.ToString();

                     
                        xlWorkSheet.Cells[8, k + 2] = xmlDataModel.generalInformationeachNodes[k].Manufacturer.ToString();

                     
                        xlWorkSheet.Cells[9, k + 2] = xmlDataModel.generalInformationeachNodes[k].Model.ToString();

                        xlWorkSheet.Cells[10, 1] = "";
                        xlWorkSheet.Cells[10, k + 2] = "";


                     
                        xlWorkSheet.Cells[11, k + 2] = xmlDataModel.generalInformationeachNodes[k].BIOSVersion.ToString();

                        
                        xlWorkSheet.Cells[12, k + 2] = xmlDataModel.generalInformationeachNodes[k].SerialNumber.ToString();

                      
                        xlWorkSheet.Cells[13, k + 2] = xmlDataModel.generalInformationeachNodes[k].PhysicalMemory.ToString();

                    
                        xlWorkSheet.Cells[14, k + 2] = xmlDataModel.generalInformationeachNodes[k].VirtualMemory.ToString();

                      
                        xlWorkSheet.Cells[15, k + 2] = xmlDataModel.generalInformationeachNodes[k].PageFileMaximumSize.ToString();

                        
                        xlWorkSheet.Cells[16, k + 2] = xmlDataModel.generalInformationeachNodes[k].PageFileLocation.ToString();

                  
                        xlWorkSheet.Cells[17, k + 2] = xmlDataModel.generalInformationeachNodes[k].OperatingSystem.ToString();

                
                        xlWorkSheet.Cells[18, k + 2] = xmlDataModel.generalInformationeachNodes[k].ServicePack.ToString();

                   
                        xlWorkSheet.Cells[19, k + 2] = xmlDataModel.generalInformationeachNodes[k].ProductId.ToString();
                        // xlWorkSheet.Cells[rowIndex + 16, k + 1] = xmlDataModel.generalInformationeachNodes[k].PageFileMaximumSize.ToString();
                        xlWorkSheet.Cells[20, k + 2] = " ";
                        int ik = 1;
                        int nextindex = 20;

                        xlWorkSheet.Cells[nextindex, 1] = "Processor Details";
                        xlWorkSheet.Cells[nextindex, 1].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                        for (int pindex = 1; pindex <= xmlDataModel.generalInformationeachNodes[k].processors.Count; pindex++)
                        {
                            xlWorkSheet.Cells[20 + pindex, k + 2] = ik + ". Procecssor: " + xmlDataModel.generalInformationeachNodes[k].processors[pindex
                                - 1].ProcessorId + " \n Speed: " + xmlDataModel.generalInformationeachNodes[k].processors[pindex - 1].ProcessorSpeed + "\n Core Quantity:" + xmlDataModel.generalInformationeachNodes[k].processors[pindex - 1].ProcessorCoreQuantity;
                            nextindex = pindex + 20 + 1;

                        }

                        //printing blank rows after processor section
                        for (int blankrowindex=0; blankrowindex<ProcessorBiggestcount- xmlDataModel.generalInformationeachNodes[k].processors.Count;blankrowindex++)
                        {
                            xlWorkSheet.Cells[nextindex + blankrowindex, k + 2] = "";
                            nextindex = nextindex + 1;
                        }

                        //networksection

                        
                       
                            for (int intdexnet = 0; intdexnet < 9; intdexnet++)
                            {

                            string x = null;
                            string y = null;
                            for (int nindex = 0; nindex < xmlDataModel.generalInformationeachNodes[k].netwroks.Count; nindex++)
                            {
                                
                                if (intdexnet == 0)
                                {
                                       x=x+(nindex+1)+". "+ xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].NetworkCard+"\n";
                                    y = "Network Card";
                                }
                                else if (intdexnet == 1)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].NetworkName + "\n";
                                    y = "Name";
                                }
                                else if (intdexnet == 2)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].IpAddress + "\n";
                                    y = "IP Address";
                                }
                                else if (intdexnet == 3)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].SubnetMask + "\n";
                                    y = "SubNet Mask";
                                }
                                else if (intdexnet == 4)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].DefaultGateway + "\n";
                                    y = "Default Gateway";
                                }
                                else if (intdexnet == 5)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].DNS_Primary + "\n";
                                    y = "DNS Primary";
                                }
                                else if (intdexnet == 6)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].MAC_Address + "\n";
                                    y = "MAC Address";
                                }
                                else if (intdexnet == 7)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].InterfaceMetric + "\n";
                                    y = "Interface Metric";
                                }
                                else if (intdexnet == 8)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].netwroks[nindex].NICDriverVersion + "\n";
                                    y = "NIC Driver Version";
                                }

                            }
                            xlWorkSheet.Cells[nextindex + intdexnet, k + 2] = x;
                            xlWorkSheet.Cells[nextindex + intdexnet, 1] = y;
                            xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Bold = true;
                            xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);

                            if (intdexnet == 8)
                            {
                                nextindex = nextindex + intdexnet;
                            }
                            }


                        // nextindex = nextindex+nindex;

                        //Drives Section
                        for (int intdexnet = 0; intdexnet < 5; intdexnet++)
                        {

                            string x = null;
                            string y =null;
                            for (int nindex = 0; nindex < xmlDataModel.generalInformationeachNodes[k].drivces.Count; nindex++)
                            {

                                if (intdexnet == 0)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].drivces[nindex].DeviceID + "\n";
                                    y = "Device ID";
                                }
                                else if (intdexnet == 1)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].drivces[nindex].FileSystem + "\n";
                                    y = "File System";
                                }
                                else if (intdexnet == 2)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].drivces[nindex].DiskSize + "\n";
                                    y = "Disk Size";
                                }
                                else if (intdexnet == 3)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].drivces[nindex].DiskFree + "\n";
                                    y = "Free Space";
                                }
                                else if (intdexnet == 3)
                                {
                                    x = x + (nindex + 1) + ". " + xmlDataModel.generalInformationeachNodes[k].drivces[nindex].DiskUsed + "\n";
                                    y = "Used";
                                }


                            }
                            xlWorkSheet.Cells[nextindex + intdexnet, k + 2] = x;
                            xlWorkSheet.Cells[nextindex + intdexnet, 1] = y;
                            xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Bold = true;

                            if (intdexnet == 5)
                            {
                                nextindex = nextindex + intdexnet;
                            }
                        }

                        //HarddiskSection
                        for (int intdexnet = 0; intdexnet < 4; intdexnet++)
                        {
                            if (intdexnet == 0)
                            {

                                xlWorkSheet.Cells[nextindex + intdexnet, 1] = "Hard Disk Configuration Type";
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Bold = true;
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                                xlWorkSheet.Cells[nextindex + intdexnet, k + 2] = xmlDataModel.generalInformationeachNodes[k].hardDiskConfiguration.Type;
                            }
                            else if (intdexnet == 1)
                            {
                                xlWorkSheet.Cells[nextindex + intdexnet, 1] = "Hard Disk Description";
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Bold = true;
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                                xlWorkSheet.Cells[nextindex + intdexnet, k + 2] = xmlDataModel.generalInformationeachNodes[k].hardDiskConfiguration.Description;
                            }
                            else if (intdexnet == 2)
                            {
                                xlWorkSheet.Cells[nextindex + intdexnet, 1] = "PNPID";
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Bold = true;
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                                xlWorkSheet.Cells[nextindex + intdexnet, k + 2] = xmlDataModel.generalInformationeachNodes[k].hardDiskConfiguration.PNPID;
                            }
                            else if (intdexnet == 3) {
                                xlWorkSheet.Cells[nextindex + intdexnet, 1] = "Driver Version";
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Bold = true;
                                xlWorkSheet.Cells[nextindex + intdexnet, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                                xlWorkSheet.Cells[nextindex + intdexnet, k + 2] = xmlDataModel.generalInformationeachNodes[k].hardDiskConfiguration.DriverVersion;
                            }
                            if (intdexnet == 3)
                            {
                                nextindex = nextindex + intdexnet;
                            }
                        }

                        //geniricDetails
                        xlWorkSheet.Cells[nextindex + 3, 2] = "System AuditTool";
                        xlWorkSheet.Cells[nextindex + 3, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 4, 2] = "System Name";
                        xlWorkSheet.Cells[nextindex + 4, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 5, 2] = "Inventory Tool Version";
                        xlWorkSheet.Cells[nextindex + 5, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 6, 2] = "Audit Tool Version";
                        xlWorkSheet.Cells[nextindex + 6, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 7, 2] = "Customer";
                        xlWorkSheet.Cells[nextindex + 7, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 8, 2] = "System";
                        xlWorkSheet.Cells[nextindex + 8, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 10, 2] = "Inventory run Started:";
                        xlWorkSheet.Cells[nextindex + 10, 2].Font.Bold = true;
                        xlWorkSheet.Cells[nextindex + 11, 2] = "Inventory run Completed:";
                        xlWorkSheet.Cells[nextindex + 11, 2].Font.Bold = true;

                        xlWorkSheet.Cells[nextindex + 4, 3] = SystemName ;
                        xlWorkSheet.Cells[nextindex + 5, 3] = InventoryToolVersion;
                        xlWorkSheet.Cells[nextindex + 6, 3] = AuditToolVersion;
                        xlWorkSheet.Cells[nextindex + 7, 3] = Customer;
                        xlWorkSheet.Cells[nextindex + 8, 3] = Cust_System;
                        xlWorkSheet.Cells[nextindex + 10, 3] = InventoryRunStarted;
                        xlWorkSheet.Cells[nextindex + 11, 3] = InventoryRunCompleted;


                    }
                    rowIndex = 0;
                }
                else if (i == 1)
                {
                    xlWorkSheet.Rows.WrapText = true;

                    //Excel.Borders border1 = xlWorkSheet.Columns[1].Borders;
                    //border1.LineStyle = Excel.XlLineStyle.;
                    //border1.Weight = 2d;                                        
                    xlWorkSheet.Cells[1, 1] = "Computer Name";
                    xlWorkSheet.Cells[1,1].Font.Bold = true;
                    xlWorkSheet.Cells[1,1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[2, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[3, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[2, 1] = "Applications (Not sorted)";
                    xlWorkSheet.Cells[2, 1].Font.Bold = true;
                    xlWorkSheet.Cells.EntireColumn[1].Interior.Color= System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                    xlWorkSheet.Cells[3, 1] = "Vendor \n Application";
                    xlWorkSheet.Cells[3, 1].Font.Bold = true;
                 

                    for (int k = 0; k < xmlDataModel.InstalledApps.Count; k++)
                    {
                        Excel.Borders border = xlWorkSheet.Columns[k + 2].Borders;
                        border.LineStyle = Excel.XlLineStyle.xlContinuous;
                        border.Weight = 2d;
                        xlWorkSheet.Cells[1, k + 2].EntireRow.Font.Bold = true;
                        xlWorkSheet.Cells[1, k + 2] = xmlDataModel.InstalledApps[k].NodeName.ToString();
                        for (int i_installed = 0; i_installed < xmlDataModel.InstalledApps[k].ApplicationID.Count;i_installed++)
                        {
                            
                            xlWorkSheet.Cells[i_installed+3, k + 2] = "Vendor :"+ xmlDataModel.InstalledApps[k].VendorID[i_installed] + "\n Application :" + xmlDataModel.InstalledApps[k].ApplicationID[i_installed];
                            
                        }


                    }

                }
                else if (i == 2)
                {
                    xlWorkSheet.Rows.WrapText = true;
                    xlWorkSheet.Cells.EntireColumn[1].Interior.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                    string[] columnnames = {"Computer Name","","Node Type","Software Version","EPKS Software Version","","HMIWeb Station & Dspbid","DSP DspBid","Configuration Studio"
        ,"Quick Build","Controll Builder","","SysMngt Version","RDM Version","","FTE Version","FTE Community","FTE Device ID",
        "FTE MultiCast Address","FTE Config Status","","AntiVirusSoftware","AntiVirus Engine","AntiVirus Pattern","","LCNP Node Address","","SQL Memory","",
        "Dsply path - no UNC","Dsply - no Recursion ","","Version Number","PHD AuthorizationKey","PHDLicenseNumber","CEJ-EJInstalled","","No.Server Scripts","No.Script Engines","","CDA Failover Flag","TPA Failover Flag"};

                    for(int columnindex=1;columnindex<=columnnames.Length;columnindex++)
                    {
                        xlWorkSheet.Cells[columnindex, 1] = columnnames[columnindex-1];
                        xlWorkSheet.Cells[columnindex, 1].Font.Bold = true;
                        xlWorkSheet.Cells[columnindex, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    }



                    for (int k = 0; k < xmlDataModel.HoneywellInstalledApplications.Count; k++)
                    {
                        Excel.Borders border = xlWorkSheet.Columns[k + 2].Borders;
                        border.LineStyle = Excel.XlLineStyle.xlContinuous;
                        border.Weight = 2d;
                        xlWorkSheet.Cells[1, k + 2].EntireRow.Font.Bold = true;


                        xlWorkSheet.Cells[1, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].NodeName.ToString();
                        //for (int i_installed = 0; i_installed < xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues.Count; i_installed++)
                        //{

                        //    xlWorkSheet.Cells[i_installed + 3, k + 2] =  xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[i_installed];

                        //}

                        xlWorkSheet.Cells[3, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[0];
                        xlWorkSheet.Cells[4, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[1];
                        xlWorkSheet.Cells[5, k + 2] = "";

                        xlWorkSheet.Cells[6, k + 2] = "";

                        xlWorkSheet.Cells[7, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[2];
                        xlWorkSheet.Cells[8, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[3];
                        xlWorkSheet.Cells[9, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[4];

                        
                        xlWorkSheet.Cells[10, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[5];
                        xlWorkSheet.Cells[11, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[6];

                        xlWorkSheet.Cells[12, k + 2] = "";

                        xlWorkSheet.Cells[13, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[7];
                        xlWorkSheet.Cells[14, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[8];
                        xlWorkSheet.Cells[15, k + 2] = "";

                        xlWorkSheet.Cells[16, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[9];
                        xlWorkSheet.Cells[17, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[10];
                        xlWorkSheet.Cells[18, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[11];
                        xlWorkSheet.Cells[19, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[12];
                        xlWorkSheet.Cells[20, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[13];
                        xlWorkSheet.Cells[21, k + 2] = "";

                        xlWorkSheet.Cells[22, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[14];
                        xlWorkSheet.Cells[23, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[15];
                        xlWorkSheet.Cells[24, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[16];

                        xlWorkSheet.Cells[25, k + 2] = "";

                        xlWorkSheet.Cells[26, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[17];
                        xlWorkSheet.Cells[27, k + 2] = "";
                        xlWorkSheet.Cells[28, k + 2] = "";
                        xlWorkSheet.Cells[29, k + 2] = "";
                        xlWorkSheet.Cells[30, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[18];
                        xlWorkSheet.Cells[31, k + 2] = xmlDataModel.HoneywellInstalledApplications[k].Applicationvalues[19];

                    }


                }
                else if (i == 3)
                {
                    xlWorkSheet.Rows.WrapText = true;
                    xlWorkSheet.Cells[1, 1] = "Computer Name";
                    xlWorkSheet.Cells[1, 1].Font.Bold = true;
                    xlWorkSheet.Cells[1, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[3, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                   
                    xlWorkSheet.Cells[3, 1] = "Licenses Details";
                    xlWorkSheet.Cells[3, 1].Font.Bold = true;
                    xlWorkSheet.Cells.EntireColumn[1].Interior.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                  
                    for (int k = 0; k < xmlDataModel.HoneywellLicenses.Count; k++)
                    {
                        Excel.Borders border = xlWorkSheet.Columns[k + 2].Borders;
                        border.LineStyle = Excel.XlLineStyle.xlContinuous;
                        border.Weight = 2d;
                        xlWorkSheet.Cells[1, k + 2].EntireRow.Font.Bold = true;
                        xlWorkSheet.Cells[1, k + 2] = xmlDataModel.HoneywellLicenses[k].NodeName.ToString();
                       
                        for (int i_installed = 0; i_installed < xmlDataModel.HoneywellLicenses[k].Licensesvalues.Count; i_installed++)
                        {

                            xlWorkSheet.Cells[i_installed + 3, k + 2] = xmlDataModel.HoneywellLicenses[k].Licensesvalues[i_installed];

                        }


                    }

                }
                else if (i == 4)
                {
                    xlWorkSheet.Rows.WrapText = true;
                    xlWorkSheet.Cells[1, 1] = "Computer Name";
                    xlWorkSheet.Cells[1, 1].Font.Bold = true;
                    xlWorkSheet.Cells[1, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[3, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[4, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[5, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[3, 1] = "Update ";
                    xlWorkSheet.Cells[3, 1].Font.Bold = true;
                    xlWorkSheet.Cells.EntireColumn[1].Interior.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                    xlWorkSheet.Cells[4, 1] = "Date";
                    xlWorkSheet.Cells[4, 1].Font.Bold = true;
                    xlWorkSheet.Cells[5, 1] = "Update ";
                    xlWorkSheet.Cells[5, 1].Font.Bold = true;
                    for (int k = 0; k < xmlDataModel.HoneywellUpdates.Count; k++)
                    {
                        int rowindex =1;
                        Excel.Borders border = xlWorkSheet.Columns[k + 2].Borders;
                        border.LineStyle = Excel.XlLineStyle.xlContinuous;
                        border.Weight = 2d;
                        xlWorkSheet.Cells[1, k + 2].EntireRow.Font.Bold = true;
                        xlWorkSheet.Cells[1, k + 2] = xmlDataModel.HoneywellUpdates[k].NodeName.ToString();
                        for (int i_installed = 0; i_installed < xmlDataModel.HoneywellUpdates[k].UpdateEntity.Count; i_installed++)
                        {
                            List<string> cl = new List<string>();
                            cl.Add("Date :" + xmlDataModel.HoneywellUpdates[k].UpdateEntity[i_installed].InstalledDate);

                            for (int l = 0; l < xmlDataModel.HoneywellUpdates[k].UpdateEntity[i_installed].UpdateName.Count; l++)
                            {
                                
                                string x = "Update :" + xmlDataModel.HoneywellUpdates[k].UpdateEntity[i_installed].UpdateName[l];
                                cl.Add(x);
                             
                            }
                            foreach (string lc in cl)
                            {

                                xlWorkSheet.Cells[rowindex+3, k + 2] = lc;
                                rowindex=rowindex+1;
                            }
                           

                        }


                    }

                }

                else if (i == 5)
                {

                    xlWorkSheet.Cells[1, 1] = "Computer Name";
                    xlWorkSheet.Cells[1, 1].Font.Bold = true;
                    xlWorkSheet.Cells[1, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[3, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[4, 1].Font.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.White);
                    xlWorkSheet.Cells[3, 1] = "UnInstall Key Details";
                    xlWorkSheet.Cells[3, 1].Font.Bold = true;
                    xlWorkSheet.Cells.EntireColumn[1].Interior.Color = System.Drawing.
ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                    xlWorkSheet.Cells[4, 1] = "Number \nKeyName \nProductName \nProductVersion \nInstallDate \nParentKey Name \n Publisher ";
                    xlWorkSheet.Cells[4, 1].Font.Bold = true;

                    for (int k = 0; k < xmlDataModel.uninstalledRegistryEntries.Count; k++)
                    {
                        Excel.Borders border = xlWorkSheet.Columns[k + 2].Borders;
                        border.LineStyle = Excel.XlLineStyle.xlContinuous;
                        border.Weight = 2d;
                        xlWorkSheet.Cells[1, k + 2].EntireRow.Font.Bold = true;
                        xlWorkSheet.Cells[1, k + 2] = xmlDataModel.uninstalledRegistryEntries[k].NodeName.ToString();

                        int rowindex = 1;
                        for (int i_installed = 0; i_installed < xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity.Count; i_installed++)
                        {
                            //List<string> cl = new List<string>();
                            //cl.Add("Date :" + xmlDataModel.HoneywellUpdates[k].UpdateEntity[i_installed].InstalledDate);

                            //for (int l = 0; l < xmlDataModel.HoneywellUpdates[k].UpdateEntity[i_installed].UpdateName.Count; l++)
                            //{

                            //    string x = "Update :" + xmlDataModel.HoneywellUpdates[k].UpdateEntity[i_installed].UpdateName[l];
                            //    cl.Add(x);

                            //}
                            //foreach (string lc in cl)
                            //{

                            //    xlWorkSheet.Cells[rowindex, k + 1] = lc;
                            //    rowindex = rowindex + 1;
                            //}

                            xlWorkSheet.Cells[rowindex+3, k + 2] = "Number :" +xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].Number + "\n KeyName :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].KeyName +"" +
                                "\n Product Name :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].ProductName+ "\n Product Version :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].ProductVersion+""+
                                "\n Install Date :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].InstallDate+"\n ParentProductName :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].ParentProductName+""+
                                "\n Parent KeyName :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].ParentKeyName+"\n Publisher :" + xmlDataModel.uninstalledRegistryEntries[k].UninstalledRegistryEntryEntity[i_installed].Publisher ;
                            ;
                            rowindex = rowindex + 1;

                        }


                    }
               
                } 






                xlWorkSheet.Name = SheetNames[i];
                
            }
            xlWorkSheet = xlWorkBook.Worksheets[1];
            xlWorkSheet.Activate();
            //   string str = DateTime.Now.ToString("mmddyyyyhhmmss");
            //xlWorkBook.SaveAs(@"C:\ProgramData\Honeywell\Service Tools\SI\Level3Data\xml2excel"+ DateTime.Now.ToString("mmddyyyyhhmmss") + ".xls");
            xlWorkBook.SaveAs(outputfilepath);
            xlWorkBook.Close();
            xlApp.Quit();

            releaseObject(xlApp);
            releaseObject(xlWorkBook);
            releaseObject(xlWorkSheet);

            //MessageBox.Show("Done .. ");



        }

    }
}
