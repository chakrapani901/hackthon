﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.txtXmlFilePath = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtCustomeFileName = new System.Windows.Forms.TextBox();
            this.chkCustomeName = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(252, 152);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Convert";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select XML File to Convert";
            // 
            // txtXmlFilePath
            // 
            this.txtXmlFilePath.Location = new System.Drawing.Point(15, 71);
            this.txtXmlFilePath.Name = "txtXmlFilePath";
            this.txtXmlFilePath.Size = new System.Drawing.Size(312, 20);
            this.txtXmlFilePath.TabIndex = 2;
            this.txtXmlFilePath.Text = "C:\\ProgramData\\Honeywell\\Service Tools\\SI\\Level3Data\\SATL1Report_ESV1B_08212017_0" +
    "40009.xml";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(333, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Browse";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txtCustomeFileName
            // 
            this.txtCustomeFileName.Location = new System.Drawing.Point(120, 115);
            this.txtCustomeFileName.Name = "txtCustomeFileName";
            this.txtCustomeFileName.Size = new System.Drawing.Size(207, 20);
            this.txtCustomeFileName.TabIndex = 24;
            this.txtCustomeFileName.Text = "ConvertedFile.xlsx";
            // 
            // chkCustomeName
            // 
            this.chkCustomeName.AutoSize = true;
            this.chkCustomeName.Checked = true;
            this.chkCustomeName.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCustomeName.Location = new System.Drawing.Point(15, 117);
            this.chkCustomeName.Name = "chkCustomeName";
            this.chkCustomeName.Size = new System.Drawing.Size(102, 17);
            this.chkCustomeName.TabIndex = 23;
            this.chkCustomeName.Text = "Excel File Name";
            this.chkCustomeName.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 236);
            this.Controls.Add(this.txtCustomeFileName);
            this.Controls.Add(this.chkCustomeName);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtXmlFilePath);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtXmlFilePath;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtCustomeFileName;
        private System.Windows.Forms.CheckBox chkCustomeName;
    }
}

