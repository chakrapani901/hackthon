﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{

    
    class XmlDataModel
    {
       
        public List<InstalledAppsEachNode> InstalledApps {   get; set;  } = new List<InstalledAppsEachNode>();

        public List<HoneywellApplicationsEachNode> HoneywellInstalledApplications { get; set; } = new List<HoneywellApplicationsEachNode>();

        public List<HoneywellLicensesEachNode> HoneywellLicenses { get; set; } = new List<HoneywellLicensesEachNode>();

        public List<HoneywellUpdatesEachNode> HoneywellUpdates { get; set; } = new List<HoneywellUpdatesEachNode>();

        public List<UninstalledRegistryEntryEachNode> uninstalledRegistryEntries { get; set; } = new List<UninstalledRegistryEntryEachNode>();

        public List<GeneralInformationeachNode> generalInformationeachNodes { get; set; } = new List<GeneralInformationeachNode>();

    }


    public class GeneralInformationeachNode
    {

        public string NodeName { get; set; }
        public string LoggedOnUser { get; set; }
        public string PartOfDomain { get; set; }
        public string DomainWorkGroupName { get; set; }

        public string CurrentTimeZone { get; set; }

        public string DaylightSavingEnabled { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string BIOSVersion { get; set; }
        public string SerialNumber { get; set; }
        public string PhysicalMemory { get; set; }
        public string VirtualMemory { get; set; }
        public string PageFileMaximumSize { get; set; }
        public string PageFileLocation { get; set; }
        public string OperatingSystem { get; set; }
        public string ServicePack { get; set; }
        public string ProductId { get; set; }

        public List<Processors> processors { get; set; } = new List<Processors>();

        public List<Networks> netwroks { get; set; } = new List<Networks>();

        public List<Drives> drivces { get; set; } = new List<Drives>();

        public HardDiskConfiguration hardDiskConfiguration { get; set; } = new HardDiskConfiguration();

    }


    public class HardDiskConfiguration
    {

        public string Type { get; set; }
        public string Description { get; set; }
        public string PNPID { get; set; }
        public string DriverVersion { get; set; }

    }

    public class Drives
    {
        public string DeviceID { get; set; }
        public string FileSystem { get; set; }
        public string DiskSize { get; set; }
        public string DiskFree { get; set; }
        public string DiskUsed { get; set; }



    }

    public class Networks
    {

        public string NetworkCard { get; set; }

        public string NetworkName { get; set; }

        public string IpAddress { get; set; }

        public string SubnetMask { get; set; }

        public string DefaultGateway { get; set; }
        public string DNS_Primary { get; set; }

        public string MAC_Address { get; set; }

        public string InterfaceMetric { get; set; }

        public string NICDriverVersion { get; set; }

    }

    public class Processors
    {

        public string ProcessorId { get; set; }

        public string ProcessorSpeed { get; set; }

        public string ProcessorCoreQuantity { get; set; }

    }


    public class InstalledAppsEachNode
    {
        public string NodeName { get; set; }
        public List<string> VendorID { get; set; } = new List<string>();
        public List<string> ApplicationID { get; set; } = new List<string>();

    }

    public class HoneywellApplicationsEachNode
    {
        public string NodeName { get; set; }
        public List<string> Applicationvalues{ get; set; }= new List<string>();


    }


    public class HoneywellLicensesEachNode
    {
        public string NodeName { get; set; }
        public List<string> Licensesvalues { get; set; } = new List<string>();

        //public string NodeType { get; set; }
        //public string SoftwareVersion { get; set; }
        //public string EPKSSoftwareVersion { get; set; }
        //public string HMIWebStationVersion { get; set; }
        //public string DSPBuilderVersion { get; set; }
        //public string ConfigStudioVersion { get; set; }
        //public string QBVersion { get; set; }
        //public string CBVersion { get; set; }
        //public string SysMngtVersion { get; set; }
        //public string RDMVersion { get; set; }

        //public string FTEVersion { get; set; }
        //public string FTECommunityName { get; set; }
        //public string FTEDeviceID { get; set; }
        //public string FTEMultiCastAddress { get; set; }
        //public string FTEConfigStatus { get; set; }


        //public string AntiVirusType { get; set; }
        //public string AntiVirusVersion { get; set; }
        //public string AntiVirusPattern { get; set; }

        //public string LCNPAddress { get; set; }

        //public string UNCIncluded { get; set; }
        //public string RecursionState { get; set; }


    }

    public class HoneywellUpdatesEachNode
    {

        public string NodeName { get; set; }
        public List<HoneywellUpdate> UpdateEntity { get; set; } = new List<HoneywellUpdate>();

    }

    public class HoneywellUpdate
    {
        
        public string InstalledDate { get; set; }
        public List<string> UpdateName { get; set; } = new List<string>();

    }

    public class UninstalledRegistryEntryEachNode
    {

        public string NodeName { get; set; }
        public List<UninstalledRegistryEntry> UninstalledRegistryEntryEntity { get; set; } = new List<UninstalledRegistryEntry>();

    }


    public class UninstalledRegistryEntry
    {
        public string Number { get; set; }
        public string KeyName { get; set; }
        public string ProductName { get; set; }
        public string ProductVersion { get; set; }
        public string InstallDate { get; set; }
        public string ParentProductName { get; set; }
        public string ParentKeyName { get; set; }
        public string Publisher { get; set; }


    }


}
